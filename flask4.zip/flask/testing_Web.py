from flask import Flask, redirect, jsonify, render_template, request, session
import pandas as pd
from read_csv import draw_si_station_chart, draw_si_station_weekday_chart, draw_jong_station_chart, draw_jong_station_weekday_chart, draw_se_station_chart, draw_se_station_weekday_chart, read_csv_and_insert_to_db
import sqlite3
import multiprocessing
import matplotlib
matplotlib.use('Agg')

app = Flask(__name__)
app.secret_key = 'supersecretkey'

users = {
    'bean': '1234'
}

search = {
    '시청', '종각', '서울'
}

# Load data from CSV file
data = pd.read_csv('flask/SUBWAY_MONTH.csv', encoding='utf-8')  # 변경: 파일 경로 수정

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect('/index2')
        else:
            return render_template('404.html', error='Invalid username or password')
    else:
        return render_template('login.html')

@app.route("/index2")
def index2():
    return render_template('index2.html')

@app.route("/data")
def data():
    conn = sqlite3.connect('flask/subway_data.db')
    cursor = conn.cursor()

    # 데이터베이스에서 데이터 가져오기
    cursor.execute("SELECT * FROM subway_data")
    rows = cursor.fetchall()
    
    conn.close()

    return render_template('data.html', rows=rows)

@app.route("/시청_station_daily_data")
def si_station_daily_data():
    draw_si_station_chart(data)
    draw_si_station_weekday_chart(data)
    
    # Filter data for '시청역'
    si_station_data = data[data['역명'] == '시청역']
    
    # Extract labels (dates) and data values (승차총승객수)
    labels = si_station_data['사용일자'].astype(str).tolist()
    dataValues = si_station_data['승차총승객수'].tolist()
    
    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)

@app.route("/종각_station_daily_data")
def jong_station_daily_data():
    draw_jong_station_chart(data)
    draw_jong_station_weekday_chart(data)
    
    # Filter data for '종각역'
    jong_station_data = data[data['역명'] == '종각역']

    # Extract labels (dates) and data values (승차총승객수)
    labels = jong_station_data['사용일자'].astype(str).tolist()
    dataValues = jong_station_data['승차총승객수'].tolist()

    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)    
    
@app.route("/서울_station_daily_data")
def se_station_daily_data():
    
    draw_se_station_chart(data)
    draw_se_station_weekday_chart(data)

    # Filter data for '시청역'
    se_station_data = data[data['역명'] == '서울역']

    # Extract labels (dates) and data values (승차총승객수)
    labels = se_station_data['사용일자'].astype(str).tolist()
    dataValues = se_station_data['승차총승객수'].tolist()

    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)

def draw_graphs(data):
    draw_si_station_chart(data)
    draw_si_station_weekday_chart(data)
    draw_jong_station_chart(data)
    draw_jong_station_weekday_chart(data)
    draw_se_station_chart(data)
    draw_se_station_weekday_chart(data)

if __name__ == "__main__":
    read_csv_and_insert_to_db()  # CSV 데이터를 데이터베이스로 이전

    # SQLite 데이터베이스 연결
    conn = sqlite3.connect('flask/subway_data.db')
    cursor = conn.cursor()

    # 데이터를 subway_data 테이블로 저장한 뒤, 다시 데이터베이스에서 읽어와서 data 변수에 저장
    data = pd.read_sql_query("SELECT * FROM subway_data", conn)

    conn.close()

    # Matplotlib 그래프 생성을 별도의 프로세스로 실행
    graph_process = multiprocessing.Process(target=draw_graphs, args=(data,))
    graph_process.start()

    # Flask 애플리케이션 실행
    app.run()

    # 프로세스 종료 대기
    graph_process.join()

