from flask import Flask, redirect, jsonify, render_template, request, session
import pandas as pd
from read_csv import draw_si_station_chart, draw_si_station_weekday_chart, draw_jong_station_chart, draw_jong_station_weekday_chart, draw_se_station_chart, draw_se_station_weekday_chart, draw_station_chart, draw_station_weekday_chart,read_csv_and_insert_to_db

app = Flask(__name__)
app.secret_key = 'supersecretkey'

users = {
    'bean': '1234'
}

# Load data from CSV file
data = pd.read_csv('flask/SUBWAY_MONTH.csv', encoding='utf-8')  # 변경: 파일 경로 수정

draw_station_chart(data)
draw_station_weekday_chart(data)
draw_si_station_chart(data)
draw_si_station_weekday_chart(data)
draw_jong_station_chart(data)
draw_jong_station_weekday_chart(data)
draw_se_station_chart(data)
draw_se_station_weekday_chart(data)

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect('/index2')
        else:
            return render_template('404.html', error='Invalid username or password')
    else:
        return render_template('login.html')

@app.route("/index2")
def index2():
    return render_template('index2.html')

@app.route("/data")
def data():
    return render_template('data.html')

@app.route("/시청_station_daily_data")
def si_station_daily_data():
    return render_template('시청_station_daily_data.html')

@app.route("/종각_station_daily_data")
def jong_station_daily_data():
    return render_template('종각_station_daily_data.html')    
    
@app.route("/서울_station_daily_data")
def se_station_daily_data():
    return render_template('서울_station_daily_data.html')


if __name__ == "__main__":
    # Flask 애플리케이션 실행
    app.run()

