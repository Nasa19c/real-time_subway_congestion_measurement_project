from flask import Flask, redirect, jsonify, render_template, request, session
import csv
import pandas as pd
from read_csv import draw_si_station_chart, draw_si_station_weekday_chart, draw_jong_station_chart, draw_jong_station_weekday_chart, draw_se_station_chart, draw_se_station_weekday_chart, read_csv_and_insert_to_db
import sqlite3

app = Flask(__name__)
app.secret_key = 'supersecretkey'

users = {
    'bean': '1234'
}

# Load data from CSV file
data = pd.read_csv('flask/SUBWAY_MONTH.csv', encoding='utf-8')  # 변경: 파일 경로 수정

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect('/index2')
        else:
            return render_template('404.html', error='Invalid username or password')
    else:
        return render_template('login.html')

@app.route("/index2")
def index2():
    return render_template('index2.html')

@app.route("/data")
def data():
    conn = sqlite3.connect('flask/subway_data.db')
    cursor = conn.cursor()

    # 데이터베이스에서 데이터 가져오기
    cursor.execute("SELECT * FROM subway_data")
    rows = cursor.fetchall()
    
    conn.close()

    return render_template('data.html', rows=rows)

@app.route("/si_station_daily_data")
def si_station_daily_data():
    draw_si_station_chart(data)
    draw_si_station_weekday_chart(data)
    
    # Filter data for '시청역'
    si_station_data = data[data['역명'] == '시청역']
    
    # Extract labels (dates) and data values (승차총승객수)
    labels = si_station_data['사용일자'].astype(str).tolist()
    dataValues = si_station_data['승차총승객수'].tolist()
    
    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)

@app.route("/jong_station_daily_data")
def jong_station_daily_data():
    draw_jong_station_chart(data)
    draw_jong_station_weekday_chart(data)
    
    # Filter data for '종각역'
    jong_station_data = data[data['역명'] == '종각역']

    # Extract labels (dates) and data values (승차총승객수)
    labels = jong_station_data['사용일자'].astype(str).tolist()
    dataValues = jong_station_data['승차총승객수'].tolist()

    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)    
    
@app.route("/se_station_daily_data")
def se_station_daily_data():
    
    draw_se_station_chart(data)
    draw_se_station_weekday_chart(data)

    # Filter data for '시청역'
    se_station_data = data[data['역명'] == '서울역']

    # Extract labels (dates) and data values (승차총승객수)
    labels = se_station_data['사용일자'].astype(str).tolist()
    dataValues = se_station_data['승차총승객수'].tolist()

    # Return the data as JSON
    return jsonify(labels=labels, dataValues=dataValues)
@app.route("/si_station_daily_data", methods=['GET', 'POST'])
@app.route("/jong_station_daily_data", methods=['GET', 'POST'])
@app.route("/se_station_daily_data", methods=['GET', 'POST'])
def station_daily_data():
    if request.method == 'POST':
        search_value = request.form['searchInput']

        graph_image = None
        
        if search_value == '종각':
            graph_image = 'jong_station_chart.png'
        elif search_value == '시청':
            graph_image = 'si_station_chart.png'
        elif search_value == '서울':
            graph_image = 'se_station_chart.png'
        
        if graph_image is not None:
            return render_template('graph.html', graph_image=graph_image, search_value=search_value)
        else:
            return render_template('data.html', search_value=search_value)
    else:
        # POST 요청이 아닌 경우, 검색어가 없는 상태로 data.html 템플릿을 표시합니다
        return render_template('data.html')
    

if __name__ == "__main__":
    draw_si_station_chart()
    draw_si_station_weekday_chart()
    draw_jong_station_chart()
    draw_jong_station_weekday_chart()
    draw_se_station_chart()
    draw_se_station_weekday_chart()
    read_csv_and_insert_to_db()  # CSV 데이터를 데이터베이스로 이전

    app.run()
